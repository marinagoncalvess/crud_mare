from flask import Flask, render_template, request, redirect, url_for
import sqlite3
import os

app = Flask(__name__)

# O caminho para o banco de dados. Está correto, mas é bom revisar se a estrutura de pastas mudou.
# Ele assume que 'database.db' estará na mesma pasta que 'app.py'
DATABASE = os.path.join(os.path.dirname(__file__), 'database.db')

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row # Permite acessar colunas como item['coluna'] ou item.coluna
    return conn

@app.route('/')
def index():
    conn = get_db_connection()
    items = conn.execute('SELECT * FROM items').fetchall()
    conn.close()
    return render_template('index.html', items=items)

@app.route('/add', methods=['POST'])
def add():
    name = request.form['name']
    if name: # Garante que o nome não é vazio
        conn = get_db_connection()
        conn.execute('INSERT INTO items (name) VALUES (?)', (name,))
        conn.commit()
        conn.close()
    return redirect(url_for('index'))

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    conn = get_db_connection()
    item = conn.execute('SELECT * FROM items WHERE id = ?', (id,)).fetchone()

    # Se o item não for encontrado, redireciona para a página inicial
    if not item:
        conn.close()
        return redirect(url_for('index'))

    if request.method == 'POST':
        name = request.form['name']
        if name: # Garante que o nome não é vazio
            conn.execute('UPDATE items SET name = ? WHERE id = ?', (name, id))
            conn.commit()
            conn.close()
            return redirect(url_for('index')) # Redireciona após salvar

    conn.close() # Garante que a conexão é fechada para requisições GET também
    return render_template('edit.html', item=item)

@app.route('/delete/<int:id>', methods=['POST'])
def delete(id):
    conn = get_db_connection()
    conn.execute('DELETE FROM items WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

if __name__ == '__main__':
    # Use debug=True apenas para desenvolvimento.
    # Em produção, desative o debug.
    app.run(debug=True)